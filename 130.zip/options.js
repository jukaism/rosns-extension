function getKeyAndCheck(keys) {
  chrome.storage.sync.get(keys, function(items) {
    Object.keys(items).forEach(ke => {
      var query = "input[name='" + ke + "']"
      var box = document.querySelector(query)
      box.checked = items[ke]
    })
  })
}

function setKey(key, value) {
  chrome.storage.sync.set(
    { [key]: value }
  )
}

var bingoOneKeyArray = Array.from(Array(49), (v, k) => 'bingoOneCheck' + k)
var bingoTwoKeyArray = Array.from(Array(49), (v, k) => 'bingoTwoCheck' + k)
var bingoThreeKeyArray = Array.from(Array(49), (v, k) => 'bingoThreeCheck' + k)
var bingoFourKeyArray = Array.from(Array(49), (v, k) => 'bingoFourCheck' + k)
window.onload = function() {
  var overall = document.querySelectorAll("input[type='checkbox']")
  overall.forEach(ov => {
    ov.addEventListener('click', function(e) {
      setKey(e.target.name, e.target.checked)
    })
  })
  getKeyAndCheck(bingoOneKeyArray)
  getKeyAndCheck(bingoTwoKeyArray)
  getKeyAndCheck(bingoThreeKeyArray)
  getKeyAndCheck(bingoFourKeyArray)
  getKeyAndCheck('noInfoChecked')
}
